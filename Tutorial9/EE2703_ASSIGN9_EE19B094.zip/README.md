# EE2703 - Assignment 9

This folder contains the code, TeX file, plots used in the TeX file and the PDF report

## Run command
```bash
python3 EE2703_ASSIGN9_EE19B094.py
```

## Input
Not Required

## Output
18 plots saved in ```plots``` folder in the same directory


