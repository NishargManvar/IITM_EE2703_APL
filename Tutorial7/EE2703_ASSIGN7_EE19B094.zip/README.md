# EE2703 - Assignment 7

This folder contains the code, TeX file, plots used in the TeX file and the PDF report

## Run command
```bash
python3 EE2703_ASSIGN7_EE19B094.py
```

## Output
11 Graphs
1) Magnitude Response of Low Pass filter
2) Magnitude Response of High pass filter
3) Step response of low pass filter
4) Step Response of high pass filter
5) Two frequency sinusoid input signal (TFS)
6) Low pass filter output for TFS
7) High pass filter output for TFS
8) Low pass filter output for low frequency damped sinusoid
8) High pass filter output for low frequency damped sinusoid
10) Low pass filter output for high frequency damped sinusoid
11) High pass filter output for high frequency damped sinusoid


