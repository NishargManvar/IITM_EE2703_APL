# EE2703 - Assignment 6 - 2

This folder contains the code, TeX file, plots used in the TeX file and the PDF report

## Run command
```bash
python3 EE2703_ASSIGN6_2_EE19B094.py
```

## Output
Q1,2 : Position vs Time for different decay constant
Q3 : Position vs Time for different frequencies
Q4 : Values of X and Y satisfying the coupled equations
Q5 : Bode plot for the transfer function of the circuit
Q6 : Output voltage for the input voltage given in the question for two time ranges