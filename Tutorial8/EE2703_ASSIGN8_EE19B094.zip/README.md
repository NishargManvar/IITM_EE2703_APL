# EE2703 - Assignment 8

This folder contains the code, TeX file, plots used in the TeX file and the PDF report

## Run command
```bash
python3 EE2703_ASSIGN8_EE19B094.py
```

## Output
6 graphs
1) Spectrum of Sin(x)
2) Spectrum of AM signal
3) Spectrum of cos^3(x)
4) Spectrum of sin^3(x)
5) Spectrum of FM signal
6) Spectrum of Gaussian signal

Errors in spectrums of reconstructed graphs of random values and gaussian


